import java.util.*;
public class Main {
    public static void main(String[] args) {

        // Ejemplo de Hashtable
        Hashtable<Integer, String> hashtable = new Hashtable<>();
        hashtable.put(1133, " Alex ");
        hashtable.put(2277, " Andres ");
        hashtable.put(3344, " Daniel ");
        System.out.println("Ejemplo de Hashtable: " + hashtable);

        // Ejemplo de Properties
        Properties propiedades = new Properties();
        propiedades.setProperty(" nombre ", " Alex ");
        propiedades.setProperty(" edad ", " 18 ");
        System.out.println(" Ejemplo de Properties: " + propiedades);

        // Ejemplo de Vector
        Vector<String> vector = new Vector<>();
        vector.add(" leon ");
        vector.add(" tigre ");
        vector.add(" gato ");
        System.out.println(" Ejemplo de Vector: " + vector);

        // Ejemplo de Enumeration
        Enumeration<String> enumeration = vector.elements();
        System.out.print("Ejemplo de Enumeration: ");
        while (enumeration.hasMoreElements()) {
            System.out.print(enumeration.nextElement() + " ");
        }
        System.out.println();

        // Ejemplo de Collection y Collections
        Collection<String> coleccion = new ArrayList<>();
        coleccion.add("pera");
        coleccion.add("mango");
        coleccion.add("banano");
        System.out.println("Ejemplo de Collection y Collections: " + coleccion);
        Collections.sort((List<String>) coleccion);
        System.out.println("Colección ordenada: " + coleccion);

        // Ejemplo de Arrays
        int[] arreglo = {5, 2, 7, 4, 1};
        System.out.println("Ejemplo de Arrays: " + Arrays.toString(arreglo));

        // Ejemplo de List y ArrayList
        List<String> lista = new ArrayList<>();
        lista.add(" calculo vectorial");
        lista.add("estructura de datos");
        lista.add(" comunicacion II ");
        lista.add(" fisica II ");
        System.out.println("Ejemplo de List y ArrayList: " + lista);

        // Ejemplo de LinkedList
        LinkedList<String> listaEnlazada = new LinkedList<>();
        listaEnlazada.add(" carro ");
        listaEnlazada.add(" bicicleta");
        listaEnlazada.add(" avion ");
        System.out.println("Ejemplo de LinkedList: " + listaEnlazada);

        // Ejemplo de Set, SortedSet, HashSet y TreeSet
        Set<Integer> conjunto = new HashSet<>();
        conjunto.add(4);
        conjunto.add(2);
        conjunto.add(6);
        conjunto.add(8);
        System.out.println("Ejemplo de Set, HashSet: " + conjunto);

        SortedSet<Integer> conjuntoOrdenado = new TreeSet<>();
        conjuntoOrdenado.add(4);
        conjuntoOrdenado.add(2);
        conjuntoOrdenado.add(6);
        conjuntoOrdenado.add(8);
        System.out.println("Ejemplo de SortedSet, TreeSet: " + conjuntoOrdenado);

        // Ejemplo de Map, HashMap, TreeMap y LinkedHashMap
        Map<String, Integer> mapa = new HashMap<>();
        mapa.put(" Alex ", 1278);
        mapa.put(" Daniel", 1354);
        mapa.put(" Alexis ", 3444);
        System.out.println("Ejemplo de Map, HashMap: " + mapa);

        TreeMap<String, Integer> mapaOrdenado = new TreeMap<>();
        mapaOrdenado.put(" Alex ", 1278);
        mapaOrdenado.put(" Daniel", 1354);
        mapaOrdenado.put(" Alexis ", 3444);
        System.out.println("Ejemplo de TreeMap: " + mapaOrdenado);

        LinkedHashMap<String, Integer> mapaLigado = new LinkedHashMap<>();
        mapaLigado.put(" Alex ", 1278);
        mapaLigado.put(" Daniel", 1354);
        mapaLigado.put(" Alexis ", 3444);
        System.out.println("Ejemplo de LinkedHashMap: " + mapaLigado);
    }
}


